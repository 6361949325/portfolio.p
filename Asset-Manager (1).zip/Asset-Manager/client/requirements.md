## Packages
framer-motion | Complex animations and page transitions
@react-three/fiber | 3D rendering for the hero section
@react-three/drei | Helpers for 3D scenes (OrbitControls, Stars, etc.)
three | Core 3D library required by fiber
maath | Math helpers for smooth 3D animations

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
}
