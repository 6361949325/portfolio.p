import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Stars, Text3D, Center } from "@react-three/drei";
import { useRef, useMemo } from "react";
import * as THREE from "three";
import { Group } from "three";

function GeometricShapes() {
  const group = useRef<Group>(null);
  
  // Create randomized shapes
  const shapes = useMemo(() => {
    return new Array(20).fill(0).map(() => ({
      position: [
        (Math.random() - 0.5) * 15,
        (Math.random() - 0.5) * 15,
        (Math.random() - 0.5) * 10
      ] as [number, number, number],
      rotation: [
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        0
      ] as [number, number, number],
      scale: Math.random() * 0.5 + 0.2,
      color: Math.random() > 0.5 ? "#ff00ff" : "#00ffff", // Neon pink or blue
      type: Math.random() > 0.5 ? "box" : "octahedron"
    }));
  }, []);

  useFrame((state) => {
    if (!group.current) return;
    // Slowly rotate the entire cluster
    group.current.rotation.y = state.clock.getElapsedTime() * 0.05;
    group.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 0.1) * 0.1;
  });

  return (
    <group ref={group}>
      {shapes.map((shape, i) => (
        <Float key={i} speed={2} rotationIntensity={2} floatIntensity={2}>
          <mesh position={shape.position} rotation={shape.rotation} scale={shape.scale}>
            {shape.type === "box" ? (
              <boxGeometry args={[1, 1, 1]} />
            ) : (
              <octahedronGeometry args={[1]} />
            )}
            <meshStandardMaterial 
              color={shape.color} 
              wireframe 
              emissive={shape.color}
              emissiveIntensity={2}
            />
          </mesh>
        </Float>
      ))}
    </group>
  );
}

export function Hero3D() {
  return (
    <div className="absolute inset-0 -z-10">
      <Canvas camera={{ position: [0, 0, 10], fov: 45 }}>
        <fog attach="fog" args={["#0a0a0f", 5, 20]} />
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#ff00ff" />
        <pointLight position={[-10, -10, -10]} intensity={1} color="#00ffff" />
        
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        <GeometricShapes />
        
      </Canvas>
      
      {/* Overlay gradient to fade bottom */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-background to-transparent" />
    </div>
  );
}
