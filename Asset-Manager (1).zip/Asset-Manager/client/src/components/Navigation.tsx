import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useState } from "react";

const links = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/education", label: "Education" },
  { href: "/skills", label: "Skills" },
  { href: "/projects", label: "Projects" },
  { href: "/achievements", label: "Achievements" },
  { href: "/contact", label: "Contact" },
];

export function Navigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Desktop Nav */}
      <nav className="fixed top-0 left-0 w-full z-50 px-6 py-4 hidden md:flex justify-between items-center backdrop-blur-sm bg-black/20 border-b border-white/5">
        <Link href="/">
          <a className="text-2xl font-bold font-display text-primary tracking-widest hover:text-shadow-neon transition-all">
            R<span className="text-secondary">HM</span>
          </a>
        </Link>

        <div className="flex gap-8">
          {links.map((link) => {
            const isActive = location === link.href;
            return (
              <Link key={link.href} href={link.href}>
                <a className="relative group py-2">
                  <span className={`font-mono text-sm tracking-widest uppercase transition-colors ${
                    isActive ? "text-secondary" : "text-muted-foreground group-hover:text-primary"
                  }`}>
                    {link.label}
                  </span>
                  {isActive && (
                    <motion.div
                      layoutId="underline"
                      className="absolute bottom-0 left-0 w-full h-[2px] bg-secondary shadow-[0_0_10px_#0ff]"
                    />
                  )}
                  <div className="absolute -bottom-1 left-0 w-0 h-[1px] bg-primary group-hover:w-full transition-all duration-300 shadow-[0_0_10px_#f0f]" />
                </a>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Mobile Nav Toggle */}
      <div className="fixed top-4 right-4 z-[60] md:hidden">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 bg-black/50 backdrop-blur border border-primary/50 text-primary rounded"
        >
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: "100%" }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: "100%" }}
          className="fixed inset-0 z-50 bg-background/95 backdrop-blur-xl flex flex-col items-center justify-center gap-8 md:hidden"
        >
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              <a 
                onClick={() => setIsOpen(false)}
                className={`text-2xl font-display uppercase tracking-widest ${
                  location === link.href ? "text-secondary text-shadow-blue" : "text-foreground hover:text-primary"
                }`}
              >
                {link.label}
              </a>
            </Link>
          ))}
        </motion.div>
      )}
    </>
  );
}
