import { Section } from "@/components/Section";
import { motion } from "framer-motion";
import { Trophy, Star, Medal } from "lucide-react";

const achievements = [
  {
    title: "Prompt Wars Winner",
    event: "MIT Thantra 2024",
    icon: <Trophy className="w-8 h-8 text-yellow-400" />,
    description: "Secured 1st place in the Prompt Engineering competition, demonstrating advanced skills in crafting precise inputs for Generative AI models."
  },
  {
    title: "Paper Presentation",
    event: "National Conference on AI",
    icon: <Medal className="w-8 h-8 text-secondary" />,
    description: "Presented research on 'CNN Architectures for Medical Diagnostics'. Received commendation for innovative approach."
  },
  {
    title: "Hackathon Finalist",
    event: "Smart India Hackathon (Internal)",
    icon: <Star className="w-8 h-8 text-primary" />,
    description: "Developed a prototype for automated crop disease detection using mobile cameras."
  }
];

export default function Achievements() {
  return (
    <div className="min-h-screen pt-24 pb-12">
      <Section>
        <h2 className="text-4xl md:text-6xl font-display text-center mb-20">
          <span className="text-accent">HALL</span>_OF_FAME
        </h2>

        <div className="grid gap-8 max-w-4xl mx-auto">
          {achievements.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.2 }}
              className="glass-panel p-6 md:p-8 rounded-2xl border border-white/5 flex flex-col md:flex-row gap-6 items-start hover:border-accent/50 transition-all group"
            >
              <div className="p-4 bg-white/5 rounded-full border border-white/10 group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              
              <div className="flex-1">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-2">
                  <h3 className="text-2xl font-display text-white">{item.title}</h3>
                  <span className="text-sm font-mono text-accent border border-accent/20 px-3 py-1 rounded-full bg-accent/5 w-fit">
                    {item.event}
                  </span>
                </div>
                <p className="text-muted-foreground font-mono leading-relaxed">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>
    </div>
  );
}
