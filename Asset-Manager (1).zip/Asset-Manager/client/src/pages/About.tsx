import { Section } from "@/components/Section";
import { motion } from "framer-motion";
import { User, MapPin, Cpu, Heart } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen pt-20">
      <Section>
        <motion.div 
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
        >
          <div className="space-y-6">
            <h2 className="text-4xl md:text-6xl font-display text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500 mb-8">
              ABOUT <span className="text-primary">ME</span>
            </h2>
            
            <div className="glass-panel p-6 rounded-lg border-l-4 border-l-primary relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 blur-[50px] group-hover:bg-primary/20 transition-all" />
              <p className="font-mono text-muted-foreground leading-relaxed text-lg">
                I am an AI & ML student with a passion for building intelligent solutions that push the boundaries of what's possible. Currently pursuing my B.E. at Maharaja Institute of Technology, Mysore, I combine theoretical knowledge with practical application in deep learning and computer vision.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 border border-white/10 rounded bg-white/5 flex items-center gap-4 hover:border-secondary/50 transition-colors">
                <MapPin className="text-secondary w-6 h-6" />
                <div>
                  <h4 className="font-display text-sm text-muted-foreground">Location</h4>
                  <p className="font-mono">Mandya, Karnataka</p>
                </div>
              </div>
              
              <div className="p-4 border border-white/10 rounded bg-white/5 flex items-center gap-4 hover:border-primary/50 transition-colors">
                <Cpu className="text-primary w-6 h-6" />
                <div>
                  <h4 className="font-display text-sm text-muted-foreground">Focus</h4>
                  <p className="font-mono">AI / ML / Deep Learning</p>
                </div>
              </div>
              
              <div className="p-4 border border-white/10 rounded bg-white/5 flex items-center gap-4 hover:border-accent/50 transition-colors">
                <Heart className="text-accent w-6 h-6" />
                <div>
                  <h4 className="font-display text-sm text-muted-foreground">Interests</h4>
                  <p className="font-mono">Prompt Engineering, CV</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
             {/* Abstract visual representation of profile since we don't have a photo */}
             <div className="aspect-square rounded-full border border-white/10 relative flex items-center justify-center p-12 overflow-hidden bg-black/50 backdrop-blur-sm box-glow">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-secondary/20 animate-spin-slow" />
                <div className="relative z-10 text-center">
                  <User className="w-32 h-32 mx-auto text-muted-foreground/20 mb-4" />
                  <div className="font-display text-2xl tracking-widest text-primary">RAKSHITHA HM</div>
                  <div className="font-mono text-xs text-secondary mt-2">SYSTEM: ONLINE</div>
                </div>
                
                {/* Decorative circles */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] border border-dashed border-white/10 rounded-full animate-spin duration-[20s]" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] h-[140%] border border-dotted border-primary/20 rounded-full animate-reverse-spin duration-[30s]" />
             </div>
          </div>
        </motion.div>
      </Section>
    </div>
  );
}
