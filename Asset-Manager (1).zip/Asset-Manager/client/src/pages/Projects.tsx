import { Section } from "@/components/Section";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { X, ExternalLink, Github, Microscope } from "lucide-react";

interface Project {
  id: number;
  title: string;
  description: string;
  details: string;
  tech: string[];
  icon: JSX.Element;
  link?: string;
}

const projects: Project[] = [
  {
    id: 1,
    title: "Medical Image Classification",
    description: "Deep Learning model for abnormality detection in medical imaging.",
    details: "Built a Convolutional Neural Network (CNN) to classify X-ray images, identifying abnormalities like pneumonia or fractures. The model was trained on a large dataset of annotated medical images, achieving significant accuracy. Used TensorFlow and Keras for model architecture, with data augmentation techniques to improve robustness.",
    tech: ["Python", "TensorFlow", "CNN", "OpenCV", "Keras"],
    icon: <Microscope className="w-12 h-12 text-primary" />,
    link: "#"
  },
  {
    id: 2,
    title: "Sales Data Analysis",
    description: "Exploratory Data Analysis (EDA) on retail sales data.",
    details: "Performed comprehensive data cleaning and visualization to uncover seasonal trends and top-selling products. Used Pandas for manipulation and Matplotlib/Seaborn for visualization. Provided actionable insights for inventory management.",
    tech: ["Python", "Pandas", "Matplotlib", "Seaborn", "Jupyter"],
    icon: <ExternalLink className="w-12 h-12 text-secondary" />, // Placeholder icon
    link: "#"
  },
  {
    id: 3,
    title: "Portfolio Website",
    description: "Futuristic, interactive portfolio built with React and Three.js.",
    details: "This website itself! Designed to showcase skills in a unique cyberpunk aesthetic. Implements complex animations with Framer Motion, 3D scenes with React Three Fiber, and a fully responsive design using Tailwind CSS.",
    tech: ["React", "TypeScript", "Three.js", "Tailwind", "Framer Motion"],
    icon: <ExternalLink className="w-12 h-12 text-accent" />,
    link: "#"
  }
];

export default function Projects() {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const selectedProject = projects.find(p => p.id === selectedId);

  return (
    <div className="min-h-screen pt-24 pb-12">
      <Section>
        <h2 className="text-4xl md:text-6xl font-display text-center mb-16 text-transparent bg-clip-text bg-gradient-to-br from-primary via-white to-secondary">
          PROJECT_<span className="text-white">ARCHIVE</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <motion.div
              key={project.id}
              layoutId={`project-${project.id}`}
              onClick={() => setSelectedId(project.id)}
              className="glass-panel group relative p-8 rounded-xl border border-white/5 cursor-pointer hover:border-primary/50 transition-colors overflow-hidden"
              whileHover={{ y: -5 }}
            >
              <div className="absolute top-0 right-0 p-4 opacity-50 group-hover:opacity-100 transition-opacity">
                <ExternalLink className="w-5 h-5 text-muted-foreground group-hover:text-white" />
              </div>
              
              <div className="mb-6 p-4 bg-white/5 rounded-full inline-block group-hover:bg-primary/10 transition-colors">
                {project.icon}
              </div>
              
              <h3 className="text-2xl font-display text-white mb-2 group-hover:text-primary transition-colors">{project.title}</h3>
              <p className="text-muted-foreground font-mono text-sm line-clamp-2">{project.description}</p>
              
              <div className="mt-6 flex flex-wrap gap-2">
                {project.tech.slice(0, 3).map(t => (
                  <span key={t} className="text-xs font-mono px-2 py-1 rounded bg-black/50 border border-white/10 text-gray-400">
                    {t}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <AnimatePresence>
          {selectedId && selectedProject && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }}
                onClick={() => setSelectedId(null)}
                className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              />
              
              <motion.div
                layoutId={`project-${selectedId}`}
                className="w-full max-w-2xl bg-[#0a0a10] border border-primary/30 rounded-2xl overflow-hidden relative z-10 shadow-[0_0_50px_rgba(180,0,255,0.2)]"
              >
                <div className="p-8">
                  <div className="flex justify-between items-start mb-6">
                    <div className="p-3 bg-primary/10 rounded-lg text-primary">
                      {selectedProject.icon}
                    </div>
                    <button 
                      onClick={() => setSelectedId(null)}
                      className="p-2 hover:bg-white/10 rounded-full transition-colors"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                  
                  <h3 className="text-3xl font-display text-white mb-4">{selectedProject.title}</h3>
                  <p className="text-gray-300 font-mono leading-relaxed mb-8 border-l-2 border-secondary pl-4">
                    {selectedProject.details}
                  </p>
                  
                  <div className="space-y-4">
                    <h4 className="font-display text-sm text-secondary">TECHNOLOGIES USED</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.tech.map(t => (
                        <span key={t} className="px-3 py-1 bg-white/5 border border-white/10 rounded text-sm font-mono text-primary">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-8 pt-6 border-t border-white/10 flex justify-end gap-4">
                     <a 
                       href={selectedProject.link} 
                       target="_blank" 
                       rel="noreferrer"
                       className="flex items-center gap-2 px-6 py-3 bg-white text-black font-bold rounded hover:bg-gray-200 transition-colors"
                     >
                       <Github className="w-4 h-4" /> View Code
                     </a>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </Section>
    </div>
  );
}
