import { Hero3D } from "@/components/Hero3D";
import { GlitchText } from "@/components/GlitchText";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, Download } from "lucide-react";

export default function Home() {
  return (
    <div className="relative h-screen w-full overflow-hidden flex items-center justify-center">
      <Hero3D />
      
      <div className="relative z-10 text-center px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-secondary font-mono tracking-[0.2em] mb-4 text-sm md:text-base uppercase">
            Mandya, Karnataka • AI & ML Engineer
          </h2>
          
          <h1 className="text-5xl md:text-8xl font-display font-black mb-6 text-white leading-tight">
            <GlitchText text="RAKSHITHA" className="block md:inline mr-4" />
            <GlitchText text="HM" className="text-primary" />
          </h1>
          
          <p className="max-w-xl mx-auto text-muted-foreground font-mono mb-10 text-lg">
            Crafting intelligent systems at the intersection of machine learning 
            and futuristic interfaces.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/projects">
              <button className="px-8 py-3 bg-primary/10 border border-primary text-primary font-mono tracking-wider hover:bg-primary hover:text-white transition-all duration-300 group box-glow rounded">
                <span className="flex items-center gap-2">
                  VIEW PROJECTS
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>
            </Link>
            
            <a href="/resume.pdf" target="_blank" rel="noopener noreferrer">
              <button className="px-8 py-3 bg-secondary/10 border border-secondary text-secondary font-mono tracking-wider hover:bg-secondary hover:text-black transition-all duration-300 group box-glow-blue rounded">
                <span className="flex items-center gap-2">
                  DOWNLOAD CV
                  <Download className="w-4 h-4" />
                </span>
              </button>
            </a>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-muted-foreground hidden md:block">
        <span className="text-xs font-mono">SCROLL TO INITIALIZE</span>
      </div>
    </div>
  );
}
