import { Section } from "@/components/Section";
import { motion } from "framer-motion";
import { Code, Terminal, Database, Cpu, Brain, Laptop } from "lucide-react";

const skills = [
  { name: "Python", category: "Languages", level: 90, icon: <Code /> },
  { name: "C / C++", category: "Languages", level: 85, icon: <Terminal /> },
  { name: "Java", category: "Languages", level: 80, icon: <Laptop /> },
  { name: "Machine Learning", category: "Core", level: 85, icon: <Brain /> },
  { name: "Deep Learning", category: "Core", level: 80, icon: <Cpu /> },
  { name: "SQL", category: "Database", level: 75, icon: <Database /> },
];

const techStack = [
  "TensorFlow", "Keras", "Scikit-learn", "OpenCV", "Pandas", "NumPy", "Git", "React", "Linux"
];

export default function Skills() {
  return (
    <div className="min-h-screen pt-24 pb-12">
      <Section>
        <h2 className="text-4xl md:text-6xl font-display text-center mb-16">
          <span className="text-primary">TECH</span>_ARSENAL
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {skills.map((skill, i) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="glass-panel p-6 rounded-lg border border-white/5 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-20 text-white">
                {skill.icon}
              </div>
              <h3 className="text-xl font-display text-white mb-2">{skill.name}</h3>
              <p className="text-xs font-mono text-muted-foreground mb-4 uppercase tracking-wider">{skill.category}</p>
              
              <div className="relative h-2 w-full bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-secondary to-primary"
                />
              </div>
              <div className="text-right mt-2 text-xs font-mono text-secondary">{skill.level}%</div>
            </motion.div>
          ))}
        </div>

        <div className="glass-panel p-8 rounded-2xl border-t border-accent/20">
          <h3 className="text-2xl font-display text-center mb-8 text-accent">LIBRARIES & TOOLS</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {techStack.map((tech, i) => (
              <motion.span
                key={tech}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ y: -5, color: "#bfff00", borderColor: "#bfff00" }}
                className="px-6 py-3 rounded border border-white/10 font-mono text-sm text-gray-300 hover:bg-accent/10 transition-all cursor-default"
              >
                {tech}
              </motion.span>
            ))}
          </div>
        </div>
      </Section>
    </div>
  );
}
