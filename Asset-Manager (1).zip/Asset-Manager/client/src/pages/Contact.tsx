import { Section } from "@/components/Section";
import { useSubmitContact } from "@/hooks/use-contact";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMessageSchema, type InsertMessage } from "@shared/schema";
import { motion } from "framer-motion";
import { Loader2, Send, Mail, Phone, MapPin } from "lucide-react";

export default function Contact() {
  const { mutate, isPending } = useSubmitContact();
  
  const form = useForm<InsertMessage>({
    resolver: zodResolver(insertMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      message: ""
    }
  });

  const onSubmit = (data: InsertMessage) => {
    mutate(data, {
      onSuccess: () => form.reset()
    });
  };

  return (
    <div className="min-h-screen pt-24 pb-12">
      <Section>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
          <div>
            <h2 className="text-5xl md:text-7xl font-display mb-8 text-white">
              GET IN <br /><span className="text-primary">TOUCH</span>
            </h2>
            <p className="text-muted-foreground font-mono text-lg mb-12">
              Ready to collaborate on the next generation of AI solutions? 
              Initialize communication via the form or direct channels.
            </p>

            <div className="space-y-6">
              <a href="mailto:rakshitha@example.com" className="flex items-center gap-4 group p-4 border border-transparent hover:border-white/10 rounded-lg transition-colors">
                <div className="p-3 bg-secondary/10 text-secondary rounded-lg">
                  <Mail />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-display">EMAIL</div>
                  <div className="text-white font-mono group-hover:text-secondary transition-colors">rakshithahm@example.com</div>
                </div>
              </a>

              <div className="flex items-center gap-4 p-4">
                <div className="p-3 bg-primary/10 text-primary rounded-lg">
                  <Phone />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-display">PHONE</div>
                  <div className="text-white font-mono">+91 XXXXXXXXXX</div>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4">
                <div className="p-3 bg-accent/10 text-accent rounded-lg">
                  <MapPin />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-display">LOCATION</div>
                  <div className="text-white font-mono">Mandya, Karnataka, India</div>
                </div>
              </div>
            </div>
          </div>

          <div className="glass-panel p-8 rounded-2xl border border-white/10 shadow-2xl relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary via-secondary to-accent" />
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-mono text-secondary uppercase tracking-widest">Identify Yourself</label>
                <input
                  {...form.register("name")}
                  className="w-full bg-black/50 border border-white/10 rounded p-3 text-white focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary/50 transition-all placeholder:text-gray-700"
                  placeholder="NAME"
                />
                {form.formState.errors.name && (
                  <span className="text-xs text-destructive font-mono">{form.formState.errors.name.message}</span>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono text-secondary uppercase tracking-widest">Communication Channel</label>
                <input
                  {...form.register("email")}
                  className="w-full bg-black/50 border border-white/10 rounded p-3 text-white focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary/50 transition-all placeholder:text-gray-700"
                  placeholder="EMAIL ADDRESS"
                />
                {form.formState.errors.email && (
                  <span className="text-xs text-destructive font-mono">{form.formState.errors.email.message}</span>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono text-secondary uppercase tracking-widest">Data Packet</label>
                <textarea
                  {...form.register("message")}
                  rows={5}
                  className="w-full bg-black/50 border border-white/10 rounded p-3 text-white focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary/50 transition-all placeholder:text-gray-700"
                  placeholder="YOUR MESSAGE..."
                />
                {form.formState.errors.message && (
                  <span className="text-xs text-destructive font-mono">{form.formState.errors.message.message}</span>
                )}
              </div>

              <button
                type="submit"
                disabled={isPending}
                className="w-full py-4 bg-secondary/10 border border-secondary text-secondary font-display tracking-widest hover:bg-secondary hover:text-black transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed group relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-secondary/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                <span className="relative flex items-center justify-center gap-2">
                  {isPending ? (
                    <>TRANSMITTING... <Loader2 className="animate-spin w-4 h-4" /></>
                  ) : (
                    <>INITIALIZE TRANSMISSION <Send className="w-4 h-4" /></>
                  )}
                </span>
              </button>
            </form>
          </div>
        </div>
      </Section>
    </div>
  );
}
