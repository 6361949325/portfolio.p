import { Section } from "@/components/Section";
import { GraduationCap, Calendar, Award } from "lucide-react";
import { motion } from "framer-motion";

const educationData = [
  {
    title: "Bachelor of Engineering (B.E.)",
    subtitle: "Artificial Intelligence & Machine Learning",
    institution: "Maharaja Institute of Technology, Mysore",
    year: "2021 - 2025 (Expected)",
    score: "CGPA: 6.95",
    active: true,
  },
  {
    title: "Pre-University Course (PUC)",
    subtitle: "PCMB",
    institution: "Government PU College for Girls, Mandya",
    year: "2019 - 2021",
    score: "Percentage: 90%",
    active: false,
  },
  {
    title: "SSLC",
    subtitle: "Secondary Education",
    institution: "St. Joseph’s Convent, Mandya",
    year: "2019",
    score: "Percentage: 90%",
    active: false,
  },
];

export default function Education() {
  return (
    <div className="min-h-screen pt-24 pb-12">
      <Section>
        <h2 className="text-4xl md:text-6xl font-display text-center mb-16">
          <span className="text-secondary">EDU</span>CATION_LOG
        </h2>

        <div className="max-w-3xl mx-auto relative">
          {/* Vertical Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-secondary to-transparent" />

          {educationData.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className={`relative flex items-center gap-8 mb-12 ${
                index % 2 === 0 ? "md:flex-row-reverse" : ""
              }`}
            >
              {/* Timeline Dot */}
              <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 bg-black border-2 border-primary rounded-full z-10 shadow-[0_0_10px_#f0f]" />

              {/* Content Spacer for layout */}
              <div className="hidden md:block w-1/2" />

              {/* Card */}
              <div className="w-full md:w-1/2 pl-20 md:pl-0 md:px-8">
                <div className={`glass-panel p-6 rounded-xl border border-white/5 hover:border-secondary/50 transition-all duration-300 group hover:translate-x-2 ${item.active ? 'border-primary/50 shadow-[0_0_15px_rgba(255,0,255,0.15)]' : ''}`}>
                  <div className="flex items-start justify-between mb-2">
                    <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 text-xs font-mono text-secondary border border-white/10">
                      <Calendar className="w-3 h-3" />
                      {item.year}
                    </span>
                    {item.active && (
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_5px_#0f0]" />
                    )}
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-1 group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground font-mono text-sm mb-4">{item.subtitle}</p>
                  
                  <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                    <GraduationCap className="w-4 h-4 text-secondary" />
                    {item.institution}
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-accent font-mono">
                    <Award className="w-4 h-4" />
                    {item.score}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>
    </div>
  );
}
