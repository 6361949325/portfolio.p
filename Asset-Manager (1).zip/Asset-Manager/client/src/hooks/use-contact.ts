import { useMutation } from "@tanstack/react-query";
import { api, type InsertMessage } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useSubmitContact() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: InsertMessage) => {
      // Validate client-side before sending if needed, but we trust zod here
      const validated = api.contact.submit.input.parse(data);
      
      const res = await fetch(api.contact.submit.path, {
        method: api.contact.submit.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400 || res.status === 500) {
          const error = await res.json();
          // Try to parse with error schemas, fallback to generic message
          throw new Error(error.message || "Failed to send message");
        }
        throw new Error("Failed to send message");
      }

      return api.contact.submit.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      toast({
        title: "Transmission Sent",
        description: "Your message has been uploaded to the mainframe.",
        variant: "default",
        className: "border-primary text-primary shadow-[0_0_20px_rgba(255,0,255,0.3)] bg-black/90",
      });
    },
    onError: (error) => {
      toast({
        title: "Transmission Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
